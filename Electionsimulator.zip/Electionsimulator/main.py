import random
import statistics



print(" Election simulator ".center(60, "~"))
pop_score = 0  #initial popularity score that starts at 0
program_counter = 5  #helps for loop to run the program five times. in reality, this could be the total popualation in a city, help with the loop
for total_popscore in range(program_counter):
    pop_score += 10  #overall total as the "for loop" runs for each number of times program counter was assigned.
    total_popscore = random.randint(
        0, 20) + pop_score  #overall total + a random amount of approval.
    print(f"Tolu defends freedom of speech on social media apps,\
 she just gained {pop_score}% popularity! Total popularity is now {total_popscore }%!"
          )
if total_popscore > 51:  #condition for win/loss of the election.
    print(f"You won! Approval rating is {total_popscore}%!"
          )  #because its a for loop
else:
    print("You were not the voter's choice, you lost the election!")




